class Channel {
  final String name;
  final String logoUrl;
  final String streamUrl;

  Channel({required this.name, required this.logoUrl, required this.streamUrl});
}
