package com.nk.live_tv

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
